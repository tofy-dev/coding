import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Trail here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Trail extends Actor
{
    public Trail() {
        setImage("red-draught.png");
    }
    
    public void act() {
        // Add your action code here.
    }
}
