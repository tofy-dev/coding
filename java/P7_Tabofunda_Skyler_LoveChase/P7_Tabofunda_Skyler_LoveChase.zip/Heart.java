import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Heart here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Heart extends Actor
{
    public Heart() {
        setImage("Heart.png");
    }
    
    public void act() {
        // Add your action code here.
    }
}
