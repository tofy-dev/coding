import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Player extends Actor
{
    int SCREEN_WIDTH = 600;
    int SCREEN_HEIGHT = 400;
    
    int P_WIDTH = new GreenfootImage("player_stand.png").getWidth();
    int P_HEIGHT = new GreenfootImage("player_stand.png").getHeight();
    
    int GRAVITY = 3;
    int SPEED = 2;
    
    int playerX;
    int playerY;
    int playerFrame = 2;
    
    public void Player() {
        setImage("player_stand.png");
    }
    
    public void act() {
        playerX = getX();
        playerY = getY();
        
        // check if falling
        if (!wallAtOffset(0, P_HEIGHT/2)) {
            playerY += GRAVITY;
            setImage("player_stand.png");
        }
        // check if moving
        else {
            GreenfootImage playerImg = new GreenfootImage("player_run_0" + playerFrame + ".png");
            
            if (Greenfoot.isKeyDown("left")) {
                if (!wallAtOffset(-P_WIDTH/2, 0) && playerX > P_WIDTH/2) playerX -= SPEED;
                if (--playerFrame < 0) playerFrame = 3;
                playerImg.mirrorHorizontally();
            } else if (Greenfoot.isKeyDown("right")) {
                if (!wallAtOffset(P_WIDTH/2, 0) && playerX < SCREEN_WIDTH - P_WIDTH/2) playerX += SPEED;
                if (++playerFrame > 3) playerFrame = 0;
            } else {
                playerImg = new GreenfootImage("player_stand.png");
            }
            
            setImage(playerImg);
        }
        
        updatePosition();
        
        // make sure it didn't fall too far down
        if (wallAtOffset(0, P_HEIGHT/2)) {
            while (wallAtOffset(0, P_HEIGHT/2-1)) {
                playerY--;
                updatePosition();
            }
        }
        // ... or is inside of a wall
        if (wallAtOffset(-P_WIDTH/2, 0)) {
            while (wallAtOffset(-P_WIDTH/2, 0)) {
                playerX++;
                updatePosition();
            }
        }
        if (wallAtOffset(P_WIDTH/2, 0)) {
            while (wallAtOffset(P_WIDTH/2, 0)) {
                playerX--;
                updatePosition();
            }
        }
    }

    public void updatePosition() {
        setLocation(playerX, playerY);
    }
    
    public boolean wallAtOffset(int dx, int dy) {
        return getOneObjectAtOffset(dx, dy, Brick.class) != null;
    }
}
