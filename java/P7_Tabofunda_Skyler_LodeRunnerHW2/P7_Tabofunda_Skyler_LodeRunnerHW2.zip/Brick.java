import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Brick extends Actor
{
    public Brick() {
        setImage("bricks.png");
    }
}
