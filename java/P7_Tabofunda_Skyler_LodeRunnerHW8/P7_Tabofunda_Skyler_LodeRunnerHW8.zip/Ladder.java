import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Ladder extends Actor
{
    public void Ladder() {
        setImage("ladder.png");
    }
}
