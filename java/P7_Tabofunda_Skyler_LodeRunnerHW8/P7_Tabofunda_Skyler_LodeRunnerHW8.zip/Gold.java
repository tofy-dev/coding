import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Gold extends Actor
{
    public Gold() {
        setImage("gold.png");
    }
}
